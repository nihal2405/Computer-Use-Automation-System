# Architecture

The repository implements the synthetic banking UI, strict component contracts,
Chromium browser adapter, session ownership, and a policy-checked shared executor.
The workflow is search → member details → accounts → savings balance. Automation
reads the visible UI and never imports mock data or calls balance APIs.

Both the discovery and replay controllers invoke the executor. The mode
label changes event metadata, not permissions. Configuration is loaded from
operator-owned YAML; malformed settings and incompatible entry URLs are rejected.
The executor uses one live browser across steps and control transfers. Discovery
supports Gemini and OpenAI structured responses; Gemini 2.5 Flash was verified live.
The model receives reviewed control descriptions and live visibility/field-state
flags, not raw member IDs, balances, names or arbitrary page text. It chooses an
action sequence within the reviewed vocabulary; it does not invent arbitrary
locators for an unknown application. Only entry navigation is bootstrapped.

# Artifact schema

Strict Pydantic contracts describe schema/capability versions, typed inputs and
outputs, target compatibility, ordered actions, and a success checkpoint. Steps
have unique IDs and optional pre/postconditions. References must name declared
inputs, and each output must have one read step. Unknown fields/actions and
unsupported versions are rejected.

A sanitized exporter removes unreviewed prose and pseudonymizes identifiers.
It validates the resulting capability and rejects changes to executable targets,
input/output names, checkpoints, or recovery conditions. A separate compiler
records only successful discovery steps after output and checkpoint verification.
It restores input references from exact matching policy templates rather than
globally substituting strings. Real provider artifacts retain a discovery run UUID;
test doubles remain development fixtures. Correlated genuine evidence is preserved
in `evidence/phase7`, alongside the separate hand-authored testing fixture.

# Determinism & error handling

The shared executor runs one step with a single deadline across preconditions,
the action, and postconditions. It enforces configured step/run limits. A failed
checkpoint yields failure without an output. Surface errors include step,
expected/observed details, and an opaque structural-evidence reference.

Only the immediately preceding identical timed-out wait may be explicitly retried,
within the configured retry bound. Clicks and submissions are never automatically
retried. Cancellation records failure; interrupted mutations close the browser
context before releasing ownership. Persistence failures close the browser rather
than returning success without an audit event.

Replay validates the artifact, binds new inputs, executes its ordered steps, and
checks the visible account owner and declared output types before returning success.
Missing members return a business outcome without outputs. Known loading conditions
permit wait-only recovery with a run-wide attempt budget and deadlines; exhaustion
or hard errors emit a sanitized intervention. No click or submission is repeated.
The fixed sequence requires no model or heuristic no-progress detector.

Discovery bounds model calls by the total run deadline and limits invalid responses.
Repeated observable states, including cycles, trigger a no-progress intervention.
Refusals, incomplete responses and provider failures never become browser actions.
Once all declared outputs are collected, code verifies completion without another
model request. Mutations after extraction are rejected; model text cannot supply
an answer or alter the completion contract.

# Heterogeneity & multi-tenant

The surface interface keeps browser-library objects out of caller contracts.
Exact accessible role/name, label, text, and scoped CSS targets are supported.
Missing and ambiguous matches fail. Frame traversal, visual targeting, native
desktop controls, and automatic popup switching remain unsupported.

Product/version markers are checked against configured compatibility. Tenant
origins and browser contexts are separate. Marker checks assume a cooperating
target; they are not authentication. A different product needs reviewed identity,
state, locator, and policy rules. Redirect enforcement uses Chromium-specific
response interception and would need a separately tested implementation for
another browser backend.

# Escalation & handoff

A shared lock enforces AUTOMATION_RUNNING → AWAITING_HUMAN → HUMAN_CONTROL →
RESUME_CHECK transitions. Human ownership blocks adapter dispatch. Resume checks
permit inspection while blocking mutations. The same page, browser context, and
cookies survive transfers. Ownership changes produce sanitized events.

Interactive discovery and replay route blocked runs to a token-protected loopback
operator UI. Browser listeners record value-free interaction categories during
human ownership. Before resuming, the coordinator checks target compatibility,
the exact requested account route, owner checkpoint, and output targets. It issues
a one-use permission to reread outputs without repeating completed navigation.
Unknown pages remain paused; cancellation and operator deadlines terminate safely.
A separate policy permits only the current member's reviewed dialog acknowledgement
POST during human control. Request restrictions otherwise remain active.

Nineteen browser tests use simulated operators, including typed-password redaction,
interrupted verification, closed windows, and failed audit writes. A separate manual operator run completed successfully and is preserved in
`evidence/phase8`; `docs/handoff.md` documents reproduction.
The DOM guard and dispatch lock assume a cooperating target/operator, not an OS
input lock. Batch commands still close the browser after returning. Human-assisted
discovery returns verified outputs without compiling a misleading model-only artifact.

# Safety

The default-deny policy binds each operation to approved actions and exact controls
or conditions. UI explanations and model-supplied operation names cannot widen it.
Actual links, input types, form destinations, and submission methods are checked.
Approved main-frame routes and static assets have separate request rules; API
fetches, background submissions, frames, popups, service workers, and WebSockets
are blocked. A one-use permit authorizes a form submission.

A Chromium response guard validates every redirect destination before following
it and blocks attachment responses. Server-side request-count tests verify that
forbidden destinations receive no requests. A browser-boundary violation latches
the session closed to further operations. These controls trust approved endpoint
semantics and operator configuration; they are not an OS-level sandbox.

Persistence retains reviewed constants and fixed diagnostic vocabulary; unknown
text, keys, and arbitrary numeric values become per-run keyed tokens. Known input
and output values are always masked. Structural DOM evidence excludes text,
values, URLs, cookies, and scripts. No raw screenshot or trace is saved. Typed event
envelopes retain generated run/session IDs, mode, step token, action, policy result,
checkpoint, retry count, and ownership. Conservative redaction reduces readability
and requires a future model controller to handle opaque references correctly.

# Cuts

The full suite passes 345 tests, including 19 handoff cases. Phase 7 contributed 326: 97 environment/contract checks, 47 mock-app checks, 30 original
browser/session checks, 56 safety/diagnostics checks, 52 replay checks, and 44
discovery/provider checks. Both member balances are
retrieved through the shared executor under both mode labels. Configuration,
request boundaries, spoofed controls, redirects, redaction, artifact export,
ownership, retries, cancellation, and persistence failure are covered.

The hand-authored artifact also retrieves the second balance in a separate process
with model/discovery imports blocked and API keys removed. Tests cover replay's
not-found, recovery exhaustion, wrong-owner checkpoints, app/permission errors,
typed outputs, intervention records, cancellation, and failed persistence.

Gemini supplied six real decisions in discovery run
`4caff583-f0a4-41e8-9236-af22520c9652`. Its generated artifact replayed successfully
for the second member with model imports blocked and API keys removed, and passed
the same 21 replay integration checks as the development fixture. Sanitized events,
the capability and a correlation/hash manifest are preserved locally.

The manual handoff run verified same-session completion after dialog resolution.
Remaining work includes integrated clean-environment acceptance and submission preparation.
Native desktop support, multi-tenant infrastructure, and a polished operator
dashboard remain intended cuts. The final assignment must demonstrate every core
requirement with actual run evidence; tests are not a substitute for discovery.

"""Safety subsystem scaffold."""

"""Handoff subsystem scaffold."""

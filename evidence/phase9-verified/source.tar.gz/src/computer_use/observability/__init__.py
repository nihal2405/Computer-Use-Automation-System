"""Observability subsystem scaffold."""

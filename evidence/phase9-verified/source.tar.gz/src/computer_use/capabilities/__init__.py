"""Capabilities subsystem scaffold."""

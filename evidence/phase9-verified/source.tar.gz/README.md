# Computer-Use Automation System

A local repository for the interface.ai computer-use assignment: learn a UI
workflow with an LLM, save it as a reusable capability, then replay it without
model decisions.

**Status: discovery, deterministic replay, and interactive handoff implemented.**
Gemini 2.5 Flash discovered the action sequence for member `1001`; its saved
capability replayed for `2002` with model imports blocked and API keys removed.
Both runs validated the account-owner checkpoint and visible outputs.
All **345 tests pass**, including 44 discovery/provider checks and 19 handoff checks. The genuine artifact
also passes all **21 replay integration checks**. Sanitized evidence is in
[evidence/phase7](evidence/phase7/README.md). Same-session human takeover and verified
resume passed both simulated-operator tests and a separate manual operator run,
which returned `8040.20 USD` in the same session. Sanitized evidence is preserved
in [evidence/phase8](evidence/phase8/README.md).
See [the handoff guide](docs/handoff.md) for the manual demo and safety limits.

## Planned demonstration

Use a local banking mock with synthetic data to search for a member, open the
member record, navigate to accounts, and read the savings balance through the UI.
Discover the workflow for one member, then replay it for a different member.
Exercise not-found, delayed load, permission denial, and an unexpected dialog
requiring human takeover of the same browser session.

The automation must not call the mock application's data endpoints or import its
data module to obtain results. The browser must navigate and read the UI.

## Repository layout

- `src/computer_use/`: schemas, configuration/validation CLI, browser surface,
  session ownership, shared executor, policy, redaction, sanitized artifact export,
  event/evidence storage, model discovery, capability compilation, and deterministic
  replay, and a local operator interface with human-event capture and verified resume.
- `mock_app/`: working Flask banking target with synthetic data and controlled scenarios.
- `config/`: validated runtime, target, and default-deny policy settings.
- `tests/`: environment, contract, banking app, and browser/session integration checks.
- `artifacts/`: ignored development capabilities.
- `evidence/`: sanitized evidence from genuine discovery and model-disabled replay.
- `REPORT.md`: proposed design under the assignment's seven required headings.
- `docs/requirements.md`: required behavior and implementation milestones.
- `docs/build-checklist.md`: ordered build checklist with a reason for each task.
- `docs/contracts.md`: implemented contract fields, rules, and deliberate limits.
- `docs/browser-sessions.md`: adapter API, targeting, waits, lifecycle, and ownership limits.

## Set up the development environment

Install [uv](https://docs.astral.sh/uv/getting-started/installation/) 0.9.13 or newer.
The project selects Python 3.13 through `.python-version`; uv can download it if
it is missing. From the repository root, run:

```bash
uv sync --locked
uv run --locked python -m playwright install chromium
uv run --locked python -m pytest -q
uv run --locked computer-use status
```

`uv sync --locked` creates the isolated `.venv`, installs the local package and
development dependencies, and uses the exact versions in `uv.lock`. Initial
setup requires network access for packages and Chromium. Subsequent environment
tests use only a temporary local server and require no model API key.

Installed tools are Flask for the mock server, Playwright/Chromium for browser
interaction, Pydantic for validation, PyYAML for configuration, and pytest for
tests. OpenAI SDK 2.54.0 supports both OpenAI Responses and Gemini's compatible
endpoint; python-dotenv 1.2.3 loads local discovery credentials.

See [environment.md](docs/environment.md) for tested versions, OS notes, clean
installation verification, and dependency update commands. The status CLI reports
`discovery_replay_ready`; both controllers share the same protected execution path.

Discovery loads the selected provider's key from the environment or ignored `.env`.
The default is Gemini: configure `GEMINI_API_KEY`. OpenAI uses `OPENAI_API_KEY`.
Provider/model selection is in `config/discovery.yaml`. Do not put secrets in tracked files.

## Implementation and demo commands

With the mock server running and a provider key configured, run genuine discovery:

```bash
uv run --locked computer-use discover --inputs '{"member_id":"1001"}' --headless
```

Replay the returned artifact path with another member, or use the preserved
artifact from the verified Gemini run:

```bash
uv run --locked python scripts/replay_without_model.py evidence/phase7/capability.json \
  --inputs '{"member_id":"2002"}' --headless
```

The verification script blocks model imports and removes API-key environment
variables. See [discovery.md](docs/discovery.md) for provider setup, observations,
stopping limits, compilation, provenance, and the scope of discovery.

Use the [shared executor guide](docs/safety-executor.md) for the policy-checked Python
API. Events and structural failure snapshots are sanitized before storage in ignored
run directories; no screenshot or raw trace is saved. Run the focused safety checks:

```bash
uv run --locked computer-use validate-config
uv run --locked python -m pytest -q tests/unit/test_safety.py tests/integration/test_safe_executor.py
```

Start the synthetic banking application:

```bash
uv run --locked python -m mock_app
```

Open [the local app](http://127.0.0.1:8000). Search for `1001` or `2002`, open the
matching member, then select **Accounts**. Their savings balances are `1250.75 USD`
and `8040.20 USD`, respectively. **Demo controls** exposes all seven exceptional
scenarios. See the [app guide](mock_app/README.md) for triggers and recovery steps.

With the server running, replay the hand-authored development workflow:

```bash
uv run --locked computer-use replay tests/fixtures/read_savings_balance.json \
  --inputs '{"member_id":"2002"}' --headless
```

It returns `8040.20 USD` with `checkpoint_verified: true` and `model_used: false`.
Change the ID to `1001` for `1250.75 USD`, or `9999` for `member_not_found`.
See [replay.md](docs/replay.md) for error scenarios, exit codes, recovery bounds,
and the Python API. The batch CLI closes its browser after each outcome. Add
`--interactive` to keep a blocked session available for takeover, or run the
self-contained demo (no model key required):

```bash
uv run --locked python scripts/handoff_demo.py
```

Open the printed operator URL and follow [the handoff instructions](docs/handoff.md).

Validate the hand-authored development artifact and an invocation without
executing it:

```bash
uv run --locked computer-use validate-capability tests/fixtures/read_savings_balance.json \
  --inputs '{"member_id":"1001"}' \
  --target tests/fixtures/mock_bank_identity.json
uv run --locked python -m pytest -q tests/unit
```

See [contracts.md](docs/contracts.md) for the implemented contracts. The hand-authored
fixture's operations and checkpoint are exercised against both members through the
replay engine in integration tests, including a subprocess that blocks model imports.

See [browser sessions](docs/browser-sessions.md) for the Python API and ownership
workflow. Run its focused checks with:

```bash
uv run --locked python -m pytest -q tests/integration/test_browser_surface.py
```

Follow the [build checklist](docs/build-checklist.md) for the implementation order
and why each component is needed. The [requirements](docs/requirements.md)
document defines the assignment's acceptance criteria.
Discovery, replay, and same-session handoff commands are implemented and tested.
The manual handoff run is preserved; remaining submission evidence is a later phase. Offline fixtures remain
labelled as fixtures and are separate from genuine model-run evidence.

## Repository scope

This repository is local only. The assignment eventually requests a public GitHub
repository with source, this README, a 1–3 page report, and real evidence. Remote
publication and submission are separate future actions.
